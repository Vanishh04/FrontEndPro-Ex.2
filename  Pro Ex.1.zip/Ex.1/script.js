const promptName = prompt('Please, enter your name', 'John');
const alertProperty = alert(`Hello, ${promptName}, great to see you!`);
